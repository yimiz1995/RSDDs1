
RSDDs1 - v3 2021-07-19 12:57am
==============================

This dataset was exported via roboflow.ai on July 18, 2021 at 4:57 PM GMT

It includes 65 images.
1 are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


