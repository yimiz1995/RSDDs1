
RSDDs1 - v2 20210719 1241am
==============================

This dataset was exported via roboflow.ai on July 18, 2021 at 4:41 PM GMT

It includes 65 images.
1 are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


